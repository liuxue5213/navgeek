## Flarum 简体中文 / Simplified Chinese 语言包

GitHub: https://github.com/Flarum-Chinese/flarum-simplified-chinese

###语言包简介

本语言包由 **[Flarum 中国开发者社区](http://flarum.org.cn)** 制作并发行

基于 [flarum/english](https://github.com/flarum/english) 翻译

遵循 [MIT 许可协议](http://opensource.org/licenses/mit-license.php)

整体语言风格较细腻自然  
符合多数中国人思维习惯


###下载链接

[选择发行版本 >>](https://github.com/Flarum-Chinese/flarum-simplified-chinese/releases)


###联系作者
如有疑问或建议  
请直接提出问题  

[Issuse on GitHub>>](https://github.com/Flarum-Chinese/flarum-simplified-chinese/issues)  

或进入社区发帖


[Flarum 中国开发者社区](http://discuss.flarum.org.cn)
