var gulp = require('flarum-gulp');

gulp({
  modules: {
    'flarum/pusher': 'src/**/*.js'
  }
});
