var gulp = require('flarum-gulp');

gulp({
  modules: {
    'flarum/subscriptions': 'src/**/*.js'
  }
});
