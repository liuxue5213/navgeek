var gulp = require('flarum-gulp');

gulp({
  modules: {
    'flarum/akismet': 'src/**/*.js'
  }
});
