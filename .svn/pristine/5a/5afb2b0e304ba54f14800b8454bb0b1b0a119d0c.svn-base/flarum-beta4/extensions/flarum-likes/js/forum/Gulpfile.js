var gulp = require('flarum-gulp');

gulp({
  modules: {
    'flarum/likes': 'src/**/*.js'
  }
});
