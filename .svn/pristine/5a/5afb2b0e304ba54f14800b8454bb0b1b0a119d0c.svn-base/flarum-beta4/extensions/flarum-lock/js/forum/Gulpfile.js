var gulp = require('flarum-gulp');

gulp({
  modules: {
    'flarum/lock': 'src/**/*.js'
  }
});
