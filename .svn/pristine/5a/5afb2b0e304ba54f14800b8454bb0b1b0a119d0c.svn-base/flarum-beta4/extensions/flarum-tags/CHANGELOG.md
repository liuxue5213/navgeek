# Change Log
All notable changes to the Tags extension will be documented in this file.
This project adheres to [Semantic Versioning](http://semver.org/).

## [0.1.0-beta.4] - 2015-11-05
### Added
- Add back button icon when it leads to the Tags page

[0.1.0-beta.4]: https://github.com/flarum/subscriptions/compare/v0.1.0-beta.3...v0.1.0-beta.4
