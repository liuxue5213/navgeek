var gulp = require('flarum-gulp');

gulp({
  modules: {
    'flarum/flags': 'src/**/*.js'
  }
});
