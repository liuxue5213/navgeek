# Change Log
All notable changes to the Flags extension will be documented in this file.
This project adheres to [Semantic Versioning](http://semver.org/).

## [0.1.0-beta.4] - 2015-11-05
### Added
- Show a success message after submitting a flag
- Expand reason descriptions and add a configurable link to community guidelines

[0.1.0-beta.4]: https://github.com/flarum/flags/compare/v0.1.0-beta.3...v0.1.0-beta.4
