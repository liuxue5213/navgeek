var gulp = require('flarum-gulp');

gulp({
  modules: {
    'flarum/suspend': 'src/**/*.js'
  }
});
